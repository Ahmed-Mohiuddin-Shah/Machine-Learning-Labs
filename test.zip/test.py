import numpy as np
import cv2
import random

# Load target image
target_image_path = "target_image.jpg"  # Path to your target image
target_image = cv2.imread(target_image_path)
# target_image = cv2.cvtColor(target_image, cv2.COLOR_BGR2RGB)
height, width, _ = target_image.shape

# Parameters
population_size = 30
generations = 100
mutation_rate = 0.1

cv2.imshow("Target Image", target_image)
cv2.waitKey(0)


# Define Object class for storing attributes of each GD object
class GDObject:
    def __init__(self):
        # Randomly choose shape and initialize attributes
        self.shape = random.choice(["circle", "triangle", "square"])
        self.x = random.randint(0, target_image.shape[1] - 1)
        self.y = random.randint(0, target_image.shape[0] - 1)
        self.size = random.randint(1, 30)  # Limit size to 30
        self.color = target_image[self.y, self.x].tolist()
        self.rotation = random.randint(0, 360)
        self.opacity = random.uniform(0.5, 1.0)

    def mutate(self):
        # Apply small random changes (mutations) to the object
        if random.random() < mutation_rate:
            self.x = min(
                max(0, self.x + random.randint(-2, 2)), target_image.shape[1] - 1
            )
            self.y = min(
                max(0, self.y + random.randint(-2, 2)), target_image.shape[0] - 1
            )
            self.size = min(30, max(1, self.size + random.randint(-10, 10)))
            self.rotation = (self.rotation + random.randint(-360, 360)) % 360
            self.opacity = min(
                1.0, max(0.5, self.opacity + random.uniform(-0.05, 0.05))
            )
            self.color = target_image[self.y, self.x].tolist()

    def render(self, canvas):
        color = (
            int(self.color[0] * self.opacity),
            int(self.color[1] * self.opacity),
            int(self.color[2] * self.opacity),
        )

        if self.shape == "circle":
            # Render as a circle
            cv2.circle(canvas, (self.x, self.y), self.size, color, -1)

        elif self.shape == "triangle":
            # Render as a triangle with rotation and random ratios
            pts = np.array(
                [
                    [
                        self.x + self.size * np.cos(np.deg2rad(self.rotation)),
                        self.y + self.size * np.sin(np.deg2rad(self.rotation)),
                    ],
                    [
                        self.x
                        + self.size * np.cos(np.deg2rad(self.rotation + 120)),
                        self.y
                        + self.size * np.sin(np.deg2rad(self.rotation + 120)),
                    ],
                    [
                        self.x
                        + self.size * np.cos(np.deg2rad(self.rotation + 240)),
                        self.y
                        + self.size * np.sin(np.deg2rad(self.rotation + 240)),
                    ],
                ],
                np.int32,
            )
            cv2.fillPoly(canvas, [pts], color)

        elif self.shape == "square":
            # Render as a square with rotation
            top_left = (
                self.x - self.size // 2,
                self.y - self.size // 2,
            )
            bottom_right = (
                self.x + self.size // 2,
                self.y + self.size // 2,
            )
            cv2.rectangle(canvas, top_left, bottom_right, color, -1)


def fitness(objects):
    # Create a blank canvas
    canvas = np.zeros_like(target_image, np.uint8)

    # Render each object
    for obj in objects:
        obj.render(canvas)

    cv2.imshow("Generated Image", canvas)
    cv2.waitKey(1)

    # Calculate fitness as the color difference between target and generated images
    diff = np.sum(np.abs(target_image - canvas))
    return diff


# Initialize population
population = [
    [GDObject() for _ in range(5000)] for _ in range(population_size)
]  # Each individual has 10 objects

# Evolutionary loop
for gen in range(generations):
    # Evaluate fitness for each individual
    fitness_scores = [fitness(individual) for individual in population]

    # Sort population by fitness (lower is better)
    sorted_population = [
        x for _, x in sorted(zip(fitness_scores, population), key=lambda pair: pair[0])
    ]

    # Select the top 10% to survive
    survivors = sorted_population[: population_size // 5]

    # Create next generation
    next_gen = []
    for _ in range(population_size):
        # Randomly pick two survivors as parents
        parent1, parent2 = random.sample(survivors, 2)
        child = [random.choice([o1, o2]) for o1, o2 in zip(parent1, parent2)]

        # Mutate child
        for obj in child:
            obj.mutate()
        next_gen.append(child)

    population = next_gen

    # # Display progress
    # if gen % 1 == 0:
    #     print(f"Generation {gen}, Fitness {min(fitness_scores)}")
        # display the generated image
        # best_individual = sorted_population[0]
        # canvas = np.zeros_like(target_image, np.uint8)
        # for obj in best_individual:
        #     obj.render(canvas)

        # cv2.imshow("Generated Image", canvas)
        # # delay for 1ms
        # cv2.waitKey(1)


# Display final result
best_individual = sorted_population[0]
canvas = np.zeros_like(target_image, np.uint8)
for obj in best_individual:
    obj.render(canvas)

cv2.imshow("Generated Image", canvas)
cv2.waitKey(0)

# Save the final result
cv2.imwrite("output.jpg", canvas)

cv2.destroyAllWindows()
